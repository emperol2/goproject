# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Letustest::Application.config.secret_token = 'cfa00a6aa883cee39d3a997848c955c3d93ab88a289558b774aa5271a5589b19784707a4ac8cf4f26aa15aa2f43311a7a6c1afd82d3e60af3c0ea9eb8910b80e'
