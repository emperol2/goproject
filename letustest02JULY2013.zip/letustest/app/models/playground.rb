class Playground < ActiveRecord::Base
  attr_accessible :country, :email, :name, :reproduce, :title, :url
end
