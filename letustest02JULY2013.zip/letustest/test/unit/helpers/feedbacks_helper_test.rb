require 'test_helper'

class FeedbacksHelperTest < ActionView::TestCase
end
