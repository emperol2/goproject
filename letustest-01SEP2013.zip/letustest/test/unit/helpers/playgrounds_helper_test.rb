require 'test_helper'

class PlaygroundsHelperTest < ActionView::TestCase
end
