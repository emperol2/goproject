require 'test_helper'

class TestersHelperTest < ActionView::TestCase
end
