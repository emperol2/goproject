require 'test_helper'

class IssuesHelperTest < ActionView::TestCase
end
