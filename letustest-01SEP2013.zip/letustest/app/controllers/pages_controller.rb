class PagesController < ApplicationController
  
  def plans
    
  end
  
  def companyinfo
    
  end
  
  def help
    
  end
  
  def contactus
    
  end
  
end
